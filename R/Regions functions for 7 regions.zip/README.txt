###########################

########   NOTE!!! ########

###########################

To run the 7-region-capable version of the regions package LOCALLY:
- open and install all of the functions contained in the files in this folcer 
- make sure you decrease your number of PCOs before you run it with 7 regions because if you leave it at 10 PCOs it will take 300 years to run
- note that only functions with _alt at the end of the file name differ from the original versions from the package